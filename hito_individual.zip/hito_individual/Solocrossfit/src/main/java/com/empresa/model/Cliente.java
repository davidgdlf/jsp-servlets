package com.empresa.model;

public class Cliente {
    
    public String nombre;
    public String correo;
    public float peso_actual;
    public String plan;
    public Cliente(String nombre, String correo, float peso_actual, String plan) {
        super();
        this.nombre = nombre;
        this.correo = correo;
        this.peso_actual = peso_actual;
        this.plan = plan;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public float getPeso_actual() {
        return peso_actual;
    }
    public void setPeso_actual(float peso_actual) {
        this.peso_actual = peso_actual;
    }
    public String getPlan() {
        return plan;
    }
    public void setPlan(String plan) {
        this.plan = plan;
    }
    
    
}