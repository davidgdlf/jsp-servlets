package com.empresa.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.empresa.dao.ClienteDAO;

import com.empresa.model.Cliente;

@WebServlet("/")
public class ClienteController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    public ClienteController() {
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
            String action = request.getServletPath();
                    
                    switch (action) {
                    case "/add":
                        addCliente(request, response);
                        break;
            
                    default:
                        tabla_registros(request, response);
                        break;
                    }
    }
    private void tabla_registros(HttpServletRequest request, HttpServletResponse response) {     
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);   
    }
    
    private void addCliente(HttpServletRequest request, HttpServletResponse response) {
        String nombre=request.getParameter("nombre");
        String correo=request.getParameter("correo");
        float peso_actual=Float.parseFloat(request.getParameter("peso_actual"));
        String plan=request.getParameter("plan");
        Cliente cliente=new Cliente(nombre, correo, peso_actual, plan);
        ClienteDAO dao=new ClienteDAO();
        dao.insertCliente(cliente);
    }
}
